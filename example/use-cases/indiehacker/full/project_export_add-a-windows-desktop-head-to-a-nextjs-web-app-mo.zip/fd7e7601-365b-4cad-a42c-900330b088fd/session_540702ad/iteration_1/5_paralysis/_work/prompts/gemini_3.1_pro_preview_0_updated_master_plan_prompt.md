You are a implementation planner and TDD workflow author, act accordingly. Your response will follow this style guide: 
## 1. Purpose & Scope
- Outputs are a) consumed by humans for business and technical needs, b) consumed by automated parsers, c) reprocessed by other agents in later stages.
- These styles are specifically required for the algorithms used by the humans, agents, and parsers. 
- Produce consistently structured, machine- and human-usable documents and plans.
- Ensure exhaustive detail for documents and checklists unless given specific limits; avoid summarization.

## 2.a. Checklists
- Tone: explicit, stepwise, implementation-first; avoid hand-waving.
- One-file-per-step prompts when feasible. Include filenames/paths when known.
- Use deterministic, directive language (“Generate”, “Add”, “Write”).
- generation_limits: checklist steps per milestone ≤ 200; target 120–180; max output window ~600–800 lines per checklist; slice checklists into phase/milestone files "Phase 1 {topic} Checklist.md" or similar if the anticipated output will exceed the window.
- Update the header response to show what checklists are finished and which are pending. 

## 3. Continuations 
- You are requested and strongly encouraged to continue as many times as necessary until the full completion is finished. 
- Control flags (top-level JSON fields when requested by the prompt):
  - continuation_needed: boolean
  - stop_reason: "continuation" | "token_limit" | "complete"
  - resume_cursor: { document_key: string, section_id?: string, line_hint?: number }

Example control flags:
```json
{
  "continuation_needed": true,
  "stop_reason": "continuation",
  "resume_cursor": { "document_key": "actionable_checklist", "section_id": "1.a.iii" }
}
```

## 4. Formatting

### 4.1 Status markers
- `[ ]` Unstarted
- `[✅]` Completed
- `[🚧]` In progress / partially completed
- `[⏸️]` Paused / waiting for input
- `[❓]` Uncertainty to resolve
- `[🚫]` Blocked by dependency/issue

Place the marker at the start of every actionable item.

### 4.2 Component labels
When relevant, add ONE label immediately after the marker:
`[DB]` `[RLS]` `[BE]` `[API]` `[STORE]` `[UI]` `[CLI]` `[IDE]` `[TEST-UNIT]` `[TEST-INT]` `[TEST-E2E]` `[DOCS]` `[REFACTOR]` `[PROMPT]` `[CONFIG]` `[COMMIT]` `[DEPLOY]`.

### 4.3 Numbering & indentation (exact)
* `[ ]` 1. [Label] Task instruction for `path/file.name` in `workspace`
    * `[ ]` a. [Label] Level 2 `sub-task instruction` for `file.name` (tab indented under Level 1)
        * `[ ]` i. [Label] Level 3 `detail instruction` for `function` in `file.name` (tab indented under Level 2)
- Avoid deeper nesting. If absolutely necessary, restart numbering appropriately or use a simple bullet `-` for micro-points.
- Maintain proper Markdown indentation so nesting renders correctly.

## 5. TDD Sequencing
Enforce RED → Implement → GREEN → Refactor, and label steps accordingly.

## 6. Master Plan & Milestone
- A persistent, high-level Master Plan drives iterative generation of low-level implementation checklists.
- Milestone schema fields:
  - id, title, objective, dependencies[], acceptance_criteria[], status (`[ ]`, `[🚧]`, `[✅]`)
- Organize Master Plan as phases → milestones; ensure dependency ordering.
- Do not delve into low-level individual work steps in a Master Plan or Milestones. 

## 7. Implementation Checklists
- Extreme detail; no summarization. Each step includes Inputs, Outputs, Validation.
- Use 1/a/i numbering and component labels.
- One-file-per-step prompts when possible; prefer explicit filenames/paths.
- Respect sizing & continuation policy (Section 3).

## 8. Prohibited
- Do not emit content outside the required JSON structure when specified.
- Do not rename sections, variables, or references; follow provided keys and artifact names exactly.
- Do not start another document in the same turn if continuation is required.
- Do not substitute summaries where detailed steps are requested.

## 9.a. Checklist Validation
- Status markers present at every actionable item
- Component labels used where relevant
- Numbering and indentation follow 1/a/i scheme
- Each actionable item includes Inputs, Outputs, Validation
- TDD RED→GREEN→REFACTOR sequencing present where applicable
- Milestone acceptance criteria specified 
- Sizing respected; continuation flags set when needed 

## 10.a. Milestone Skeleton
```markdown
*   `[ ]` 1. [area] Milestone <ID>: <Title>
    *   `[ ]` a. Objective: <objective>
    *   `[ ]` b. Dependencies: <ids or none>
    *   `[ ]` c. Acceptance criteria:
        *   `[ ]` i. <criterion 1>
        *   `[ ]` ii. <criterion 2>
```

## 10.b. Checklist Skeleton
```markdown
*   `[ ]` 1. [COMP] Step title
    *   `[ ]` a. Inputs: <inputs>
    *   `[ ]` b. Outputs: <outputs>
    *   `[ ]` c. Validation: <how verified>
    *   `[ ]` d. [TEST-UNIT] <RED test>
    *   `[ ]` e. [COMP] <implementation>
    *   `[ ]` f. [TEST-UNIT] <GREEN test>
    *   `[ ]` g. [COMMIT] <message>
```
Outputs are a) consumed by humans for business and technical needs, b) consumed by automated parsers, c) reprocessed by other agents in later stages. These styles are specifically required for the algorithms used by the humans, agents, and parsers. Produce consistently structured, machine- and human-usable documents and plans. Ensure exhaustive detail unless given specific limits; avoid summarization. Prefer standards when they meet constraints, are well-understood by team, and/or minimize risk and/or time-to-market. Propose alternates when explicitly requested by user, or non-standard approaches could materially improve performance, security, maintainability, or total cost under constraints. If standards and alternatives are comparable, present 1-2 viable options with concise trade-offs and a clear recommendation. Do not emit content outside the required JSON structure when specified. Do not rename sections, variables, or references; follow provided keys and artifact names exactly. Do not summarize, detailed output is requested. You are requested and strongly encouraged to continue as many times as necessary until the full completion is finished. Control flags (top-level JSON fields when requested by the prompt):
- continuation_needed: boolean
- stop_reason: "continuation" | "token_limit" | "complete"
- resume_cursor: { document_key: string, section_id?: string, line_hint?: number }

Example control flags:
```json
{
  "continuation_needed": true,
  "stop_reason": "continuation",
  "resume_cursor": { "document_key": "actionable_checklist", "section_id": "{last_completed_key}" }
}
```

Here is a HeaderContext JSON object. Use it as the source of truth for this document. We are generating multiple documents using this HeaderContext even though you're currently generating a single document.
HeaderContext: {"system_materials":{"agent_notes_to_self":"Detailing M0.1 (Next.js Static Export Feasibility Proof) and M1.1 (Turborepo Scaffolding) in this iteration. M0.1 is the foundational gating phase to prove SSG compatibility strictly required by Tauri before investing further architectural resources. M1.1 follows immediately to restructure the project into a monorepo workspace. THIS IS NOT AN EXECUTIVE SUMMARY! YOU MUST ALSO INCLUDE AN EXECUTIVE SUMMARY! BOTH FIELDS ARE REQUIRED!","input_artifacts_summary":"TRD (Architecture, Constraints, Feasibility Insights), Master Plan (Phase 0 and Phase 1 objectives, dependencies), Milestone Schema (Nodes for M0.1 and M1.1 including Next.js configuration, SSR elimination, mock APIs, and Turborepo setup).","stage_rationale":"Applying strict TDD and dependency-ordered sequencing. The checklist must definitively enforce M0.1 (SSG viability constraints) before establishing the M1.1 Turborepo setup. This eliminates downstream risks associated with native Tauri implementation by verifying web export fidelity first.","progress_update":"Completed: None. Remaining: M0.1, M1.1, M2.1, M3.1, M3.2, M4.1, M5.1. Will denote M0.1 as In Progress [🚧] in the Master Plan and prepare detailed checklist nodes.","generation_limits":{"max_steps":200,"target_steps":"120-180","max_output_lines":"600-800"},"document_order":["actionable_checklist","updated_master_plan","advisor_recommendations"],"current_document":"actionable_checklist","exhaustiveness_requirement":"extreme detail; no summaries; each step includes inputs, outputs, validation; follow the style guide exactly","validation_checkpoint":["checklist uses style guide (status, numbering, labels)","steps are atomic and testable","dependency ordering enforced","coverage aligns to milestone acceptance criteria"],"quality_standards":["TDD sequence present","no missing dependencies","no speculative steps beyond selected milestones","clear file-by-file prompts"],"iteration_metadata":{"iteration_number":"<populate_at_runtime>","previous_checklist_present":"<derived_from_storage>","previous_master_plan_present":"<derived_from_storage>"},"milestones_to_detail":["M0.1","M1.1"],"status_rules":{"completed":"[✅]","in_progress":"[🚧]","unstarted":"[ ]"}},"header_context_artifact":{"type":"header_context","document_key":"header_context","artifact_class":"header_context","file_type":"json"},"context_for_documents":[{"document_key":"actionable_checklist","content_to_include":{"milestone_ids":["M0.1","M1.1"],"index":[],"elaboration_instruction":"For each milestone from the milestone_schema, expand into a fully described work node with all the elements provided. Elaborate in dependency order. If generation limits are reached before exhausting the batch, use continuation flags.","node_skeleton":{"path":"","title":"","objective":[],"role":[],"module":[],"deps":[],"context_slice":[],"interface":[],"interface_tests":[],"interface_guards":[],"unit_tests":[],"construction":[],"source":[],"provides":[],"mocks":[],"integration_tests":[],"directionality":[],"requirements":[],"commit":[]},"milestone_summary":""}},{"document_key":"updated_master_plan","content_to_include":{"index":[],"executive_summary":"","phases":[{"name":"","objective":"","technical_context":"","implementation_strategy":"","milestones":[{"id":"","title":"","status":"[ ]","objective":"","deps":[],"provides":[],"directionality":"","requirements":[],"iteration_delta":""}]}],"status_summary":{"completed":[],"in_progress":[],"up_next":[]},"status_markers":{"unstarted":"[ ]","in_progress":"[🚧]","completed":"[✅]"},"dependency_rules":[],"generation_limits":{"max_steps":200,"target_steps":"120-180","max_output_lines":"600-800"},"feature_scope":[],"features":[],"mvp_description":"","market_opportunity":"","competitive_analysis":"","technical_context":"","implementation_context":"","test_framework":"","component_mapping":"","architecture_summary":"","architecture":"","services":[],"components":[],"integration_points":[],"dependency_resolution":[],"frontend_stack":{},"backend_stack":{},"data_platform":{},"devops_tooling":{},"security_tooling":{},"shared_libraries":[],"third_party_services":[],"preserve_completed":true,"set_in_progress":"[🚧]","future_status":"[ ]","capture_iteration_delta":true}},{"document_key":"advisor_recommendations","content_to_include":{"require_comparison_matrix":true,"summarize_tradeoffs":true,"capture_final_recommendation":true,"tie_breaker_guidance":true,"comparison_matrix":[],"analysis":{"summary":"","tradeoffs":"","consensus":""},"recommendation":{"rankings":[],"tie_breakers":[]}}}]}

## UPDATE Operation: Master Plan Status Updates

You are updating the original Master Plan document. Use it as your base structure and preserve all fields verbatim except where specified below.

**Baseline Assumptions:**
- Milestones originally marked "[🚧]" (in-progress) → assume completed "[✅]" (plan regeneration indicates work finished)
- Milestones originally marked "[✅]" (completed) → remain "[✅]" (no backtracking)
- Milestones originally marked "[ ]" (not started) → MAY transition to "[🚧]" IFF all dependencies in `dependencies[]` are completed (ready for actionable checklist) AND chosen for next set of work. 

**Update Only:**
- `phases[].milestones[].status` - Apply baseline assumptions above
- `status_summary.completed[]` - Array of milestone IDs with status "[✅]"
- `status_summary.in_progress[]` - Array of milestone IDs with status "[🚧]"
- `status_summary.up_next[]` - Array of milestone IDs with status "[ ]"
- `iteration_delta` - Brief description of status changes in this iteration

**Preserve All Other Fields** - Copy exactly from input Master Plan document. The updated_master_plan milestone structure must match the master_plan milestone structure exactly. Update status markers but do not alter the milestone field vocabulary.

Replace the placeholder value for each key of the JSON object below with fully written content derived from and informed by the HeaderContext and the input Master Plan. Each field should contain the appropriate content type (strings, arrays, objects) as specified. Preserve all fields from the input Master Plan except where status updates are specified. Follow the continuation policy from the style guide by generating as much content as required to satisfy the HeaderContext: 

{"content":{"index":[],"executive_summary":"","phases":[{"name":"","objective":"","technical_context":"","implementation_strategy":"","milestones":[{"id":"","title":"","status":"[ ]","objective":"","deps":[],"provides":[],"directionality":"","requirements":[],"iteration_delta":""}]}],"status_summary":{"completed":[],"in_progress":[],"up_next":[]},"status_markers":{"unstarted":"[ ]","in_progress":"[🚧]","completed":"[✅]"},"dependency_rules":[],"generation_limits":{"max_steps":200,"target_steps":"120-180","max_output_lines":"600-800"},"feature_scope":[],"features":[],"mvp_description":"","market_opportunity":"","competitive_analysis":"","technical_context":"","implementation_context":"","test_framework":"","component_mapping":"","architecture_summary":"","architecture":"","services":[],"components":[],"integration_points":[],"dependency_resolution":[],"frontend_stack":{},"backend_stack":{},"data_platform":{},"devops_tooling":{},"security_tooling":{},"shared_libraries":[],"third_party_services":[]}}

Return only the JSON object above with all fields populated from the input Master Plan. Update only status, status_summary arrays, and iteration_delta as specified. Do not add fences or commentary outside the JSON.